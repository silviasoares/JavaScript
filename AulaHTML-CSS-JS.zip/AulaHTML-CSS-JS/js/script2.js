document.write("<h1>Estamos executando o script2.js</h1>");
document.write("Esse script está em um arquivo externo e é referenciado no final do body do HTML");