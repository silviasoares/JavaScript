document.write("<h1>Estamos executando o script.js</h1>");
document.write("Esse script está em um arquivo externo e é referenciado no header do HTML");
console.log("Esse script está no cabeçalho do HTML");
console.log("Primeiro");
console.log("Segundo");



var teste = 1;
document.write("<br>O valor da variável teste é " + teste);
teste = 'joao';
document.write("<br>O valor da variável teste é " + teste);


nome = 'joao';
console.log(nome)


var v1 = 5;
let v2 = null;
const v3 = 'teste';


console.log(typeof(v1));
console.log(typeof(v2));
console.log(typeof(v3));
console.log(typeof NaN); // tipo number
console.log(typeof +Infinity); // tipo number
console.log(typeof null); // tipo number

//Operadores de comparação
const number = "1"
console.log (number == 1);//true
console.log (number === 1); //false

console.log("Ele disse funcionou");

//adicionando uma lista no body do html
var lista =  ['Arroz', 'Feijão', 'Carne', 'Macarrão'];
var listaUl = document.createElement('ul');
var body = document.getElementsByTagName('body');

console.log(listaUl);
console.log(body);

//alert("Vamos criar uma lista aqui!");

body[0].appendChild(listaUl);

for(var  i=0;i<lista.length;i++) {
    var liFor = document.createElement('li');
    var textoLi = document.createTextNode(lista[i]);
    liFor.appendChild(textoLi);
    listaUl.appendChild(liFor);
}

document.write("A lista não ordenada <b>ACIMA</b> foi criada dinamicamente via JavaScript");

var obj = {
    nome:"Joao",
    sobrenome:"Santos",
    profissao:"professor",
    salario: 5000
};

console.log(obj);
console.log("O salário do " + obj.nome + " é " + obj.salario);

var arr = [5, "Café", true, {teste1: 1, teste2: 2}, false];
console.log(arr);
console.log(arr[1]);
console.log(typeof arr);

if (arr[2])
{
    console.log("Teste IF")
}


// Operadores de comparação ==, ===, !=, >, <, >=, <= 
if (obj.salario > '4000') {
    console.log("Salário acima de 4000");
}







